import hashlib
import hmac
import json
import os
import sys
import time
from urllib.request import Request, urlopen

from config_loader import load_runtime_config


def classify_source(value: str) -> str:
    lower = value.lower()
    if 'youtube.com/watch' in lower or 'youtu.be/' in lower:
        return 'youtube_url'
    if value.startswith('http://') or value.startswith('https://'):
        return 'url'
    return 'file_path'


def read_callback_context() -> dict | None:
    session_key = os.environ.get('SKILLHUB_SESSION_KEY', '').strip()
    if not session_key:
        return None
    callback_mode = os.environ.get('SKILLHUB_CALLBACK_MODE', 'inject_then_chat_send').strip() or 'inject_then_chat_send'
    return {
        'sessionKey': session_key,
        'callbackMode': callback_mode,
    }


def build_payload(
    source_type: str,
    source_ref: str,
    skill_slug: str = 'video-summarize',
    youtube_mode: str = 'auto',
    model: str | None = None,
) -> dict:
    job_type = 'youtube_summarize' if source_type == 'youtube_url' else 'video_summarize'
    payload = {
        'skillSlug': skill_slug,
        'jobType': job_type,
        'youtubeMode': youtube_mode,
        'sourceType': source_type,
        'sourceRef': source_ref,
    }
    callback_context = read_callback_context()
    if callback_context:
        payload['callbackContext'] = callback_context
    if model:
        payload['model'] = model
    return payload


def hash_request_body(body: str) -> str:
    return hmac.new(b'', body.encode(), hashlib.sha256).hexdigest()


def build_signed_headers(timestamp: str, nonce: str, body: str, secret: str) -> dict:
    body_hash = hash_request_body(body)
    sig_input = f'{timestamp}{nonce}{body_hash}'
    signature = hmac.new(secret.encode(), sig_input.encode(), hashlib.sha256).hexdigest()
    return {
        'X-SkillHub-Timestamp': timestamp,
        'X-SkillHub-Nonce': nonce,
        'X-SkillHub-Body-SHA256': body_hash,
        'X-SkillHub-Signature': signature,
        'Content-Type': 'application/json',
    }


def resolve_runtime_secret(signing_context: str = 'skillhub-internal-v1') -> str:
    shared_secret = os.environ.get('SKILLHUB_RUNTIME_SHARED_SECRET', '').strip()
    if shared_secret:
        return shared_secret

    gateway_token = os.environ.get('GOCLAW_GATEWAY_TOKEN', '').strip()
    return hmac.new(
        gateway_token.encode(),
        signing_context.encode(),
        hashlib.sha256,
    ).hexdigest()


def submit(source: str, skill_slug: str = 'video-summarize') -> dict:
    config = load_runtime_config()
    source_type = classify_source(source)
    payload = build_payload(
        source_type,
        source,
        skill_slug,
        youtube_mode=config.get('youtubeMode', 'auto'),
        model=config.get('defaultModel'),
    )
    body = json.dumps(payload)
    timestamp = str(int(time.time()))
    nonce = f'{timestamp}-{os.urandom(8).hex()}'
    runtime_secret = resolve_runtime_secret()
    headers = build_signed_headers(timestamp, nonce, body, runtime_secret)
    req = Request(
        f"{config.get('skillHubUrl', 'http://skillhub:4080')}/api/jobs",
        data=body.encode(),
        headers=headers,
        method='POST',
    )
    with urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())


def main():
    if len(sys.argv) < 2:
        raise SystemExit('usage: submit_video_job.py <url-or-youtube-url>')
    print(json.dumps(submit(sys.argv[1])))


if __name__ == '__main__':
    main()
